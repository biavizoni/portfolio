const express = require("express");
const app = express();

app.use(express.json());

let livros = [];

app.get("/livros", (req, res) => {
  res.json(livros);
});

app.post("/livros", (req, res) => {
  livros.push(req.body);
  res.send("Livro adicionado");
});

app.listen(3000, () => console.log("Servidor rodando"));
