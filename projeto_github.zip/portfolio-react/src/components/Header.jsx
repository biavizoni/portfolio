export default function Header() {
  return (
    <header>
      <h1>Meu Portfólio</h1>
    </header>
  );
}